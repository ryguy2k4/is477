snakemake --cores 1 all
python ./scripts/dag.py | dot -Tpng > ../results/workflow.png